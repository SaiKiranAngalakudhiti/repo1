// const jwt = require("jsonwebtoken");

// const config = 'somekey';

// const verifyToken = (req, res, next) => {
//   req.user = {email:null, verified:false}
//   const token =
//     req.body.token || req.query.token || req.headers["x-access-token"];

//   if (!token) {
//     return res.status(403).send("A token is required for authentication");
//   }
//   try {
//     // jwt.verify(token, config, function (err,data){
//     //     if(! (err && typeof data=== 'undefined')) {
//     //         console.log("inside ")
//     //         return req.user = {email:data.email, verified:true}
//     //       next()}
//     //   })
//     const decoded = jwt.verify(token, config);
//     //console.log(decoded)
//     return req.user = {email:decoded.email, verified:true}
//     //req.user = {email:data.email, verified:true}
//     //req.user = decoded;
//   } catch (err) {
//     return res.status(401).send("Invalid Token");
//   }
//   return next();
// };

const jwt = require("jsonwebtoken");

const config = 'somekey';

const verifyToken = (req, res, next) => {
  const token =
    req.body.token || req.query.token || req.headers["x-access-token"];

  if (!token) {
    return res.status(403).send("A token is required for authentication");
  }
  try {
    console.log("verified");
    const decoded = jwt.verify(token, config);
    req.user = decoded;
  } catch (err) {
    return res.status(401).send("Invalid Token");
  }
  return next();
};

module.exports = verifyToken;