const config = {
    db: {
      host: "localhost",
      user: "root",
      password: "",
      database: "what_should_i_wear",
    }
  };
  module.exports = config;