var express = require('express');
var router = express.Router();
const mysql = require('mysql');
const config = require('../config/dbconfig');

const connection = mysql.createConnection(config.db);
router.get('/getWeatherData/:id', function(req, res, next) {
    let postal_code = req.params.id;
    console.log(postal_code);
    connection.query('SELECT * FROM weather where postal_code = ?;',[postal_code],
     function(error, results, fields) {
        if(results.length>0){
            res.send(results);
        }
    });
});
module.exports = router;