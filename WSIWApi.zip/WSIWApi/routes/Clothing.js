var express = require('express');
var router = express.Router();
const mysql = require('mysql');
const verifyToken = require('../middleware/auth');
const config = require('../config/dbconfig');



const connection = mysql.createConnection(config.db);

router.get('/getClothing', function(req, res, next) {
    connection.query('SELECT * FROM clothing;', function(error, results, fields) {
        if(results.length>0){
            //console.log(results);
            res.send(results);
        }
    });
});
router.post('/addClothing',verifyToken, function(request,res, next) {
	let clothing_type = request.body.clothing_type;
    let clothing_image_path = request.body.clothing_image_path;
    let clothing_category_id = request.body.clothing_category_id;
    //let category_name = request.body.category_name;
	// Ensure the input fields exists and are not empty
	if (clothing_type!='' && clothing_image_path!='' && clothing_category_id!='') {
		// Execute SQL query that'll select the account from the database based on the specified username and password
		connection.query('INSERT INTO clothing(clothing_type, clothing_image_path, clothing_category_id) VALUES (?,?,?) ', 
        [clothing_type,clothing_image_path,clothing_category_id], async function(error, results, fields) {
			// If there is an issue with the query, output the error
			if (error) throw error;
			// If the account exists
			if (results.affectedRows>0) {   
				res.status(200).send({message:'clothing created'});
			} else {
				res.status(403).send({message:'error'});
			}			
			res.end();
		});
	} else {
		res.status(403).send({message:'Please provide all clothing details!'});
		res.end();
	}
});
router.put('/editClothing', verifyToken, function(request,res, next) {
    let clothing_id = request.body.clothing_id;
	let clothing_type = request.body.clothing_type;
    let clothing_image_path = request.body.clothing_image_path;
    let clothing_category_id = request.body.clothing_category_id;
    //let category_name = request.body.category_name;
	// Ensure the input fields exists and are not empty
	if (clothing_type!='' && clothing_image_path!='' && clothing_category_id!='' ) {
		// Execute SQL query that'll select the account from the database based on the specified username and password
		connection.query('UPDATE clothing SET clothing_type = ?, clothing_image_path = ?, clothing_category_id = ? WHERE clothing_id = ? ;', 
        [clothing_type,clothing_image_path,clothing_category_id,clothing_id], function(error, results, fields) {
            // If there is an issue with the query, output the error
            if (error) throw error;
            // If the account exists
            if (results.affectedRows > 0) {
                //console.log('password updated');
                res.status(200).send({ message: 'clothing_id id '+ clothing_id + ' is updated' });
            } else {
                //console.error('no user exists in db to update');
            res.status(403).send({ message: 'error updating '+clothing_id +'location id' });
            }			
            res.end();
        });
	} 
    else {
		res.status(403).send({message:'Please provide all clothing details!'});
		res.end();
	}
});
router.delete('/deleteClothing/:id',verifyToken, function(request,res, next) {
	let clothing_id = request.params.id;
	// Ensure the input fields exists and are not empty
	if (request.params.id > 0) {
		// Execute SQL query that'll select the account from the database based on the specified username and password
		connection.query('DELETE FROM clothing WHERE clothing_id = ? ;', [clothing_id], function(error, results, fields) {
            // If there is an issue with the query, output the error
            if (error) throw error;
            else {
                res.status(200).send({ message: 'clothing id '+clothing_id +' is deleted' });
            }			
            res.end();
        });
	} 
    else {
		res.status(403).send({message:'Please provide clothing id!'});
		res.end();
	}
});
module.exports = router;
