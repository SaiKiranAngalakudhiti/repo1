import { Card } from "@mui/material";
import DataTable from "./DataTable";

function TableData() {
  const data = [
    {
      id: 1,
      categoryName: "Top",
      clothingName: "Heavy Top",
    },
    {
      id: 2,
      categoryName: "Pants",
      clothingName: "Heavy Pants",
    },
    {
      id: 3,
      categoryName: "Jackets",
      clothingName: "Heavy Top",
    },
    {
      id: 4,
      categoryName: "Boots",
      clothingName: "Heavy Boots",
    },
    {
      id: 5,
      categoryName: "Socks",
      clothingName: "Double Socks",
    },
    {
      id: 6,
      categoryName: "Mask",
      clothingName: "Face Mask",
    },
  ];

  return (
    <Card>
      <DataTable tableData={data} />
    </Card>
  );
}

export default TableData;
