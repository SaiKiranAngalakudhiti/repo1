import { Card } from "@mui/material";
import DataTable from "./DataTable";

function TableData() {
  const data = [
    {
      id: 1,
      clothingType: "Heavy Top",
      clothinCategory: "Top",
      appTemp_Start: "9",
      appTemp_End: "13",
    },
    {
      id: 2,
      clothingType: "Moderate Top",
      clothinCategory: "Top",
      appTemp_Start: "9",
      appTemp_End: "13",
    },
    {
      id: 3,
      clothingType: "Long-Sleeve",
      clothinCategory: "Top",
      appTemp_Start: "9",
      appTemp_End: "13",
    },
    {
      id: 4,
      clothingType: "Heavy Pants",
      clothinCategory: "Pants",
      appTemp_Start: "9",
      appTemp_End: "13",
    },
    {
      id: 5,
      clothingType: "Heavy Mittens",
      clothinCategory: "Mittens",
      appTemp_Start: "9",
      appTemp_End: "13",
    },
    
  ];

  return (
    <Card>
      <DataTable tableData={data} />
    </Card>
  );
}

export default TableData;
