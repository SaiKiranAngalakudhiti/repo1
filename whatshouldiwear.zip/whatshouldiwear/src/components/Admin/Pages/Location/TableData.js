import { Card } from "@mui/material";
import DataTable from "./DataTable";

function TableData() {
  const locationData = [
    {
      id: 1,
      postalCaode: "12072",
      latitude: "42.88102",
      longitude: "-74.3616",
      city: "Fultonville",
      state: "New York",
      IsAvailable: false,
    },
    {
      id: 2,
      postalCaode: "14221",
      latitude: "42.88102",
      longitude: "-74.3616",
      city: "Buffalo",
      state: "New York",
      IsAvailable: false,
    },
    {
      id: 3,
      postalCaode: "85001",
      latitude: "42.88102",
      longitude: "-74.3616",
      city: "Pheonix",
      state: "Arizona",
      IsAvailable: false,
    },
    {
      id: 4,
      postalCaode: "80001",
      latitude: "42.88102",
      longitude: "-74.3616",
      city: "Denver",
      state: "Colorado",
      IsAvailable: false,
    },
    {
      id: 5,
      postalCaode: "30002",
      latitude: "42.88102",
      longitude: "-74.3616",
      city: "Atlanta",
      state: "Georgia",
      IsAvailable: false,
    },
    
  ];

  return (
    <Card>
      <DataTable tableData={locationData} />
    </Card>
  );
}

export default TableData;
