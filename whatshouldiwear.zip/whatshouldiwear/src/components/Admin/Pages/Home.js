export default function Preference() {
  return <h1>Preference</h1>
}