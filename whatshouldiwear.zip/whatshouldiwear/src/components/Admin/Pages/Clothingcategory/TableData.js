import { Card } from "@mui/material";
import DataTable from "./DataTable";

function TableData() {
  const data = [
    {
      id: 1,
      categoryName: "Top",
    },
    {
      id: 2,
      categoryName: "Pants",
    },
    {
      id: 3,
      categoryName: "Jackets",
    },
    {
      id: 4,
      categoryName: "Boots",
    },
    {
      id: 5,
      categoryName: "Socks",
    },
    {
      id: 6,
      categoryName: "Facemask",
    },
  ];

  return (
    <Card>
      <DataTable tableData={data} />
    </Card>
  );
}

export default TableData;
