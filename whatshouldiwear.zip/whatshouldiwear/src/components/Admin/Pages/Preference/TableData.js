import { Card } from "@mui/material";
import DataTable from "./DataTable";

function TableData() {
  const data = [
    {
      id: 1,
      prefCatType: "Sport",
      preference: "Casual",
    },
    {
      id: 2,
      prefCatID: "2",
      prefCatType: "Sport",
      preference: "Run",
    },
    {
      id: 3,
      prefCatType: "Sport",
      preference: "Casual",
    },
    {
      id: 4,
      prefCatID: "3",
      prefCatType: "Feel",
      preference: "Workout",
    },
    {
      id: 5,
      prefCatType: "Feel",
      preference: "Casual",
    },
    {
      id: 6,
      prefCatType: "Feel",
      preference: "Casual",
    },
  ];

  return (
    <Card>
      <DataTable tableData={data} />
    </Card>
  );
}

export default TableData;
