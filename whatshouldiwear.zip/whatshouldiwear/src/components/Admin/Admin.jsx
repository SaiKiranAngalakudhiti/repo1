import { Component } from "react";
import './Admin.css';

class Admin extends Component{
    render(){
        return(
                <div>I am Admin</div>
        );
    }
}
export default Admin;