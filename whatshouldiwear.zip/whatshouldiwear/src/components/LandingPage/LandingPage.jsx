import { Component } from "react";


class LandingPage extends Component{
    render(){
        return(
            <div>Landing Page</div>
            
        );
    }
}
export default LandingPage;